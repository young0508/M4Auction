package model;

import java.util.Date;

public class UserDTO {
    private String memberId;
    private String passwd;
    private String nickname;
    private int virtualMoney;
    private Date regDate;

    public UserDTO() {}

    public UserDTO(String memberId, String passwd, String nickname, int virtualMoney, Date regDate) {
        this.memberId = memberId;
        this.passwd = passwd;
        this.nickname = nickname;
        this.virtualMoney = virtualMoney;
        this.regDate = regDate;
    }

    public String getMemberId() {
        return memberId;
    }
    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getPasswd() {
        return passwd;
    }
    public void setPasswd(String passwd) {
        this.passwd = passwd;
    }

    public String getNickname() {
        return nickname;
    }
    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public int getVirtualMoney() {
        return virtualMoney;
    }
    public void setVirtualMoney(int virtualMoney) {
        this.virtualMoney = virtualMoney;
    }

    public Date getRegDate() {
        return regDate;
    }
    public void setRegDate(Date regDate) {
        this.regDate = regDate;
    }
}
